package br.edu.utfpr.pb.plataformaDoacao.service;

import br.edu.utfpr.pb.plataformaDoacao.model.Categoria;

public interface CategoriaService extends CrudService<Categoria, Long>{

}
