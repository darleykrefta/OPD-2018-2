package br.edu.utfpr.pb.plataformaDoacao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.utfpr.pb.plataformaDoacao.model.Cidade;

public interface CidadeRepository extends JpaRepository<Cidade, Long>{

}
