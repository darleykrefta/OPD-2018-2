package br.edu.utfpr.pb.plataformaDoacao.service;

import br.edu.utfpr.pb.plataformaDoacao.model.Endereco;

public interface EnderecoService extends CrudService<Endereco, Long> {

}
