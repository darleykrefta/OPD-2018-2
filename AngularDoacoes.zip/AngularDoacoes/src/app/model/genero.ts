export class Genero {
    id: number;
    nome: string;
}
