package br.edu.utfpr.pb.plataformaDoacao.service;

import br.edu.utfpr.pb.plataformaDoacao.model.Pessoa;

public interface PessoaService extends CrudService<Pessoa, Long> {

}
