package br.edu.utfpr.pb.plataformaDoacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlataformaDoacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlataformaDoacaoApplication.class, args);
	}
}
