export class Produtora {
    id: number;
    nome: string;
}
