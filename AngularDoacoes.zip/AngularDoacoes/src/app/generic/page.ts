export class Page<T>{

    totalElements;
    content: T[];
    totalPages: number;
    last: boolean;
    numberOfElements: number;
    sort: any;
    first: boolean;
    size: number;
    number: number;
}
