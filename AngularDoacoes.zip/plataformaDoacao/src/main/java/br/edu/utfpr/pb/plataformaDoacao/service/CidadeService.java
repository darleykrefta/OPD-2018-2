package br.edu.utfpr.pb.plataformaDoacao.service;

import br.edu.utfpr.pb.plataformaDoacao.model.Cidade;

public interface CidadeService  extends CrudService<Cidade, Long>{

}
